import FdEmailBtn from "./FdEmailBtn/FdEmailBtn";

import FdGoogleBtn from "./FdGoogleBtn/FdGoogleBtn";

export { FdEmailBtn, FdGoogleBtn };
