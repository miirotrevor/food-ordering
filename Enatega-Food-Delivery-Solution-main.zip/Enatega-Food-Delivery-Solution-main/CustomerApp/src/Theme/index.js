import { COLORS } from './Colors'
import THEME from './Theme'

export { COLORS, THEME }
