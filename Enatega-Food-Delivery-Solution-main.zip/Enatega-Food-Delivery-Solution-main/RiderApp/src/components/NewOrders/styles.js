const styles = {
  flex: {
    flex: 1
  }
}

export default styles
