# React Tutorial - Create a Point of Sale System for Beginners in 1 Hour (React POS)

This project was built for teaching React for beginners in 1 Hour. Students learn how to set up a real world react project and build a Point of Sale System. The video for this tutorial is available on Devtamin's Youtube Channel, [https://www.youtube.com/watch?v=8E7Xwy0lXlg](https://www.youtube.com/watch?v=8E7Xwy0lXlg). Please, enjoy the video and subscribe Devtamin on Youtube. 

## How to set up the project

- Clone this respository to your computer
- Access to the project folder on the computer via Termaial or Git Bash
- Excute `npm install` to download all necessary packages
- Excute `npm start` to start the project










