import ChildcomponentTwo from "./ChildcomponentTwo";

const ChildcomponentOne = () => {
  return <ChildcomponentTwo />;
};

export default ChildcomponentOne;
