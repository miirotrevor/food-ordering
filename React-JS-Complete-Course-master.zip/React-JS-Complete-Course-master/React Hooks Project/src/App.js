import logo from "./logo.svg";
import "./App.css";
// import UseRefHook from "./Topics/UseRefHook";
//import UseEffectsHook from "./Topics/UseEffectsHook";
//import UseReducerHook from "./Topics/UseReducerHook";
//import ParentContextApi from "./Topics/ContextApiDemo/ParentContextApi";
//import ParentRefComponet from "./Topics/ForwardRefDemo/ParentRefComponet";
// import ControlledComponent from "./Topics/ControlAndUnControlComps/ControlledComponent";
// import UncontrolledComponent from "./Topics/ControlAndUnControlComps/UncontrolledComponent";
//import EnvDemo from "./Topics/EnvDemo";
import CustomHooksDemo from "./Topics/CustomHooks/CustomHooksDemo";

function App() {
  return (
    <div>
      {/* <UseRefHook /> */}
      {/* <UseEffectsHook /> */}
      {/* <UseReducerHook /> */}
      {/* <ParentContextApi /> */}
      {/* <ParentRefComponet /> */}
      {/* <ControlledComponent />
      <br />
      <UncontrolledComponent /> */}
      {/* <EnvDemo /> */}
      <CustomHooksDemo />
    </div>
  );
}

export default App;
