import React from "react";

function ErrorCom() {
  return (
    <main>
      <h1>There's some error, please contact admin for more details!!</h1>
    </main>
  );
}

export default ErrorCom;
