import React from "react";

function Contactus() {
  return (
    <div>
      <h1>Hi, I am Contact us page..</h1>
    </div>
  );
}

export default Contactus;
