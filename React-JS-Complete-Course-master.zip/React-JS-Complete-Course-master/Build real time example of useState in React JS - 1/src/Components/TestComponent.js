import CompositionComponent from "./CompositionComponent";

function TestComponent() {
  return (
    <CompositionComponent>
      <h2>I, am Test Component!!</h2>
    </CompositionComponent>
  );
}

export default TestComponent;
