import "./App.css";
import ManageBook from "./components/managebooks/ManageBook";

function App() {
  return (
    <div className="App">
      <h1>Redux Complete Tutorial...</h1>
      <ManageBook />
    </div>
  );
}

export default App;
