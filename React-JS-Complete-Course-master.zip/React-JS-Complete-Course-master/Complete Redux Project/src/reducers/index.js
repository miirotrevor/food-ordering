import reducerManageBooks from "./reducerManageBooks";
import { combineReducers } from "redux";

const rootReducer = combineReducers({
  reducerManageBooks,
});

export default rootReducer;
